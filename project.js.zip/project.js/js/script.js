const products = [
  {
    id: 1,
    name: "Laptop",
    price: 800,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400"
  },
  {
    id: 2,
    name: "Phone",
    price: 500,
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400"
  },
  {
    id: 3,
    name: "Headphones",
    price: 100,
    image: "https://images.unsplash.com/photo-1510070009289-b5bc34383727?w=400"
  },
  {
    id: 4,
    name: "Keyboard",
    price: 50,
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400"
  },
  {
  id: 5,
  name: "Mouse",
  price: 30,
  image: "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=400"
},
  {
    id: 6,
    name: "Monitor",
    price: 200,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&fit=crop&h=300"
  }
];



function showPage(pageId) {
  document.querySelectorAll("section").forEach(sec => sec.classList.remove("active"));
  document.getElementById(pageId).classList.add("active");
}

function renderProducts(containerId, count = products.length) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = "";
  products.slice(0, count).forEach(p => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.innerHTML = `
      <img src="${p.image}" alt="${p.name}">
      <h3>${p.name}</h3>
      <p>$${p.price}</p>
      <button onclick="addToCart(${p.id})">Add to Cart</button>
    `;
    container.appendChild(card);
  });
}

function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  const product = products.find(p => p.id === id);
  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.quantity++;
  } else {
    cart.push({...product, quantity: 1});
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

function renderCart() {
  const cartTable = document.getElementById("cart-items");
  if (!cartTable) return;
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cartTable.innerHTML = "";
  cart.forEach((item, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${item.name}</td>
      <td>$${item.price}</td>
      <td>${item.quantity}</td>
      <td>$${item.price * item.quantity}</td>
      <td><button onclick="removeFromCart(${index})">Remove</button></td>
    `;
    cartTable.appendChild(row);
  });
}

function removeFromCart(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

document.addEventListener("DOMContentLoaded", () => {
  renderProducts("featured-products", 2);
  renderProducts("products-container");
  renderCart();

  const form = document.getElementById("contact-form");
  if (form) {
    form.addEventListener("submit", e => {
      e.preventDefault();
      const email = document.getElementById("email").value;
      if (!email.includes("@")) {
        alert("Enter a valid email");
        return;
      }
      alert("Message sent successfully!");
      form.reset();
    });
  }
});
